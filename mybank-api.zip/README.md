# mybank-api

API Rest


## Levantar aplicación (dev)
  - **Java Application**
  - Parámetro VM arguments/options "-Dspring.profiles.active=dev"
 